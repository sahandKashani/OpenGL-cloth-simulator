varying float depth;


void main() {
    gl_FragColor = vec4(depth, depth, depth, 0);
    
}